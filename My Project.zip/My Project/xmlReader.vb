﻿Imports System.IO
Imports System
Imports System.Xml
Public Class XMLReader

End Class

Public Class CheckedItem
    Public NodeType As Integer
    Public NodeID As Integer
    Public NodeTittle As String
    Public Checked As Boolean
End Class