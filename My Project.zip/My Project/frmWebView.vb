﻿Imports WeifenLuo.WinFormsUI.Docking
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Diagnostics
Imports DW.RtfWriter
Imports FastColoredTextBoxNS
Imports System.Text.RegularExpressions
Imports GDF
Imports Properties
Imports RTF
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Windows.Forms
Imports System.IO
Partial Public Class frmWebView
    Inherits DockContent

    Dim path1 As New TummoPath
    Dim filename As String
    Dim _tempTextbox As New FastColoredTextBox
    Public RTFText As String
    Dim _projectManager As New ProjectManager

    Public Function RemoveTag(_word As String) As String
        Return Regex.Replace(_word, "<.*?>", "")
    End Function
    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) 
        Dim sb As RTFBuilderbase = New RTFBuilder()

        BuilderCode(sb)

        'Me.rtbView.Rtf = sb.ToString()
    End Sub

    Private Sub BuilderCode(sb As RTFBuilderbase)
        Dim rtb1 As New FastColoredTextBox
        rtb1.Text = RTFText
        Dim clrWord As System.Drawing.Color = System.Drawing.Color.FromArgb(181, 29, 44)
        Dim clrSub As System.Drawing.Color = System.Drawing.Color.FromArgb(112, 173, 71)
        Dim clrCategory As System.Drawing.Color = System.Drawing.Color.FromArgb(98, 156, 93)
        Dim clrUL As System.Drawing.Color = System.Drawing.Color.FromArgb(238, 170, 71)
        Dim clrOL As System.Drawing.Color = System.Drawing.Color.FromArgb(0, 112, 192)
        Dim clrLI As System.Drawing.Color = System.Drawing.Color.FromArgb(102, 102, 102)
        Dim clrNote As System.Drawing.Color = System.Drawing.Color.FromArgb(196, 89, 17)
        Dim clrText As System.Drawing.Color = System.Drawing.Color.FromArgb(0, 176, 240)

        For i = 0 To rtb1.Lines.Count - 1
            Dim str As String = rtb1.GetLineText(i)
            sb.Append("")

            'sb.AppendLine("")
            If str.StartsWith("<wo>") Then
                str = RemoveTag(str)
                sb.FontSize(26).Font(RTFFont.Arial).FontStyle(System.Drawing.FontStyle.Bold).ForeColor(clrWord).Append(str & " ")
            ElseIf str.StartsWith("<su>") Then
                str = RemoveTag(str)
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrSub).Append(str & " ")
            ElseIf str.StartsWith("<ul>") Then
                str = RemoveTag(str)
                'sb.FontSize(24).Font(RTFFont.WingDings).ForeColor(clrUL).Append("q ")
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrUL).Append("► " & str & " ")
            ElseIf str.StartsWith("<ol>") Then
                str = RemoveTag(str)
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrOL).Append("♦ " & str & " ")
            ElseIf str.StartsWith("<li>") Then
                str = RemoveTag(str)
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrLI).Append("→ " & str & " ")
            ElseIf str.StartsWith("<no>") Then
                str = RemoveTag(str)
                sb.FontSize(20).Font(RTFFont.Arial).ForeColor(clrNote).Append(str & " ")
            ElseIf str.StartsWith("<tx>") Then
                str = RemoveTag(str)
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrText).Append(str & " ")
            ElseIf str.StartsWith("<b>") Then
                str = RemoveTag(str)
                sb.FontSize(24).Font(RTFFont.Arial).ForeColor(clrText).Append(" " & str & " ")
            End If

        Next

        sb.AppendPara()
    End Sub

    Private Sub BuilderCode2(sb As RTFBuilderbase)
        Dim rtb1 As New FastColoredTextBox
        rtb1.Text = RTFText
        Dim clrWord As System.Drawing.Color = System.Drawing.Color.FromArgb(181, 29, 44)
        Dim clrSub As System.Drawing.Color = System.Drawing.Color.FromArgb(112, 173, 71)
        Dim clrCategory As System.Drawing.Color = System.Drawing.Color.FromArgb(98, 156, 93)
        Dim clrUL As System.Drawing.Color = System.Drawing.Color.FromArgb(238, 170, 71)
        Dim clrOL As System.Drawing.Color = System.Drawing.Color.FromArgb(0, 112, 192)
        Dim clrLI As System.Drawing.Color = System.Drawing.Color.FromArgb(102, 102, 102)
        Dim clrNote As System.Drawing.Color = System.Drawing.Color.FromArgb(196, 89, 17)
        Dim clrText As System.Drawing.Color = System.Drawing.Color.FromArgb(0, 176, 240)

        For i = 0 To rtb1.Lines.Count - 1
            Dim str As String = rtb1.GetLineText(i)
            sb.Append("")

            'sb.AppendLine("")
            If str.StartsWith("<wo>") Then
                str = RemoveTag(str)
                sb.FontSize(26).Font(RTFFont.Arial).FontStyle(System.Drawing.FontStyle.Bold).ForeColor(clrWord).AppendLine(str & " ")
            ElseIf str.StartsWith("<su>") Then
                str = RemoveTag(str)
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrSub).AppendLine(str & " ")
            ElseIf str.StartsWith("<ul>") Then
                str = RemoveTag(str)
                'sb.FontSize(24).Font(RTFFont.WingDings).ForeColor(clrUL).Append("q ")
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrUL).AppendLine(vbTab & "► " & str & " ")
            ElseIf str.StartsWith("<ol>") Then
                str = RemoveTag(str)
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrOL).AppendLine(vbTab & "♦ " & str & " ")
            ElseIf str.StartsWith("<li>") Then
                str = RemoveTag(str)
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrLI).AppendLine(vbTab & "→ " & str & " ")
            ElseIf str.StartsWith("<no>") Then
                str = RemoveTag(str)
                sb.FontSize(20).Font(RTFFont.Arial).ForeColor(clrNote).AppendLine("---")
                sb.FontSize(20).Font(RTFFont.Arial).ForeColor(clrNote).AppendLine(str & " ")
            ElseIf str.StartsWith("<tx>") Then
                str = RemoveTag(str)
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrText).AppendLine(str & " ")
            ElseIf str.StartsWith("<b>") Then
                str = RemoveTag(str)
                sb.FontSize(24).Font(RTFFont.Arial).ForeColor(clrText).AppendLine(str & " ")
            Else
                sb.FontSize(22).Font(RTFFont.Arial).ForeColor(clrText).AppendLine(str & " ")
            End If

        Next

        sb.AppendPara()
    End Sub

    Public Sub BuildCode()
        Dim sb As RTFBuilderbase = New RTFBuilder()

        BuilderCode2(sb)

        'Me.rtbView.Rtf = sb.ToString()
    End Sub
    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs)
        Dim sb As RTFBuilderbase = New RTFBuilder()

        BuilderCode2(sb)



        'Me.rtbView.Rtf = sb.ToString()
    End Sub

    Private Function FindIndex(line As String, word As String) As Integer
        If line <> "" Then
            Return line.IndexOf(word)
        Else
            Return -1
        End If
    End Function
    Private Sub frmWebView_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub cboMode_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMode.SelectedIndexChanged
        mUniform.StyleCSS = cboMode.Text
    End Sub
End Class

