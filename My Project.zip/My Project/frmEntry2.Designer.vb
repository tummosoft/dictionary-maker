﻿Imports WeifenLuo.WinFormsUI.Docking
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmEntry2
    Inherits DockContent

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEntry2))
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.cboStatus = New System.Windows.Forms.ToolStripComboBox()
        Me.btNewEntry = New System.Windows.Forms.ToolStripButton()
        Me.btComplete = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.dropItems = New System.Windows.Forms.ToolStripDropDownButton()
        Me.btInsertAt = New System.Windows.Forms.ToolStripDropDownButton()
        Me.btDelete = New System.Windows.Forms.ToolStripButton()
        Me.btClear = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.btMoveUp = New System.Windows.Forms.ToolStripButton()
        Me.btMoveDown = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.mnExample1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnExample2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnExample3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnExample4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.btReview = New System.Windows.Forms.ToolStripButton()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.listEntry = New System.Windows.Forms.DataGridView()
        Me.checked = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Atrributes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Text = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtCode = New FastColoredTextBoxNS.FastColoredTextBox()
        Me.menuOnText = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnReview = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnCut = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnCopy = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnPaste = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnUpcase = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnLowcase = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnTittleCase = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnJoinLines = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnSplitLines = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator18 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnTrimSpaces = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.btBack = New System.Windows.Forms.ToolStripButton()
        Me.btNext = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.btBold = New System.Windows.Forms.ToolStripButton()
        Me.btItalic = New System.Windows.Forms.ToolStripButton()
        Me.btUnderline = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.btParaLeft = New System.Windows.Forms.ToolStripButton()
        Me.btParaCenter = New System.Windows.Forms.ToolStripButton()
        Me.btParaRight = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.btUL1 = New System.Windows.Forms.ToolStripButton()
        Me.btOL1 = New System.Windows.Forms.ToolStripButton()
        Me.btLI1 = New System.Windows.Forms.ToolStripButton()
        Me.btLabel = New System.Windows.Forms.ToolStripButton()
        Me.btSuperScript = New System.Windows.Forms.ToolStripButton()
        Me.btLine = New System.Windows.Forms.ToolStripButton()
        Me.btLink = New System.Windows.Forms.ToolStripButton()
        Me.btuLNum = New System.Windows.Forms.ToolStripDropDownButton()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.IIIIIIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ABCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btTable = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.btColors = New System.Windows.Forms.ToolStripButton()
        Me.btTextColors = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.btClearFormating = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.btReplace = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.cboSymbol = New System.Windows.Forms.ToolStripComboBox()
        Me.btInsert = New System.Windows.Forms.ToolStripButton()
        Me.colorsText = New System.Windows.Forms.ColorDialog()
        Me.backgroudBuildCode = New System.ComponentModel.BackgroundWorker()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.listEntry, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel3.SuspendLayout()
        CType(Me.txtCode, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.menuOnText.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.TableLayoutPanel2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.TableLayoutPanel3)
        Me.SplitContainer1.Size = New System.Drawing.Size(768, 458)
        Me.SplitContainer1.SplitterDistance = 190
        Me.SplitContainer1.TabIndex = 1
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.ToolStrip1, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.TabControl1, 0, 1)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 2
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(768, 190)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1, Me.cboStatus, Me.btNewEntry, Me.btComplete, Me.ToolStripSeparator10, Me.dropItems, Me.btInsertAt, Me.btDelete, Me.btClear, Me.ToolStripSeparator1, Me.btMoveUp, Me.btMoveDown, Me.ToolStripSeparator16, Me.ToolStripButton1, Me.ToolStripSeparator8, Me.btReview})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(768, 25)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.ForeColor = System.Drawing.Color.Maroon
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(39, 22)
        Me.ToolStripLabel1.Text = "Status"
        '
        'cboStatus
        '
        Me.cboStatus.ForeColor = System.Drawing.Color.MidnightBlue
        Me.cboStatus.Items.AddRange(New Object() {"Incomplete", "Completed"})
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(100, 25)
        Me.cboStatus.Text = "Completed"
        '
        'btNewEntry
        '
        Me.btNewEntry.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btNewEntry.Image = CType(resources.GetObject("btNewEntry.Image"), System.Drawing.Image)
        Me.btNewEntry.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btNewEntry.Name = "btNewEntry"
        Me.btNewEntry.Size = New System.Drawing.Size(23, 22)
        Me.btNewEntry.Text = "New entry"
        '
        'btComplete
        '
        Me.btComplete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btComplete.Image = CType(resources.GetObject("btComplete.Image"), System.Drawing.Image)
        Me.btComplete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btComplete.Name = "btComplete"
        Me.btComplete.Size = New System.Drawing.Size(23, 22)
        Me.btComplete.Text = "Save entry"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 25)
        '
        'dropItems
        '
        Me.dropItems.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.dropItems.Image = CType(resources.GetObject("dropItems.Image"), System.Drawing.Image)
        Me.dropItems.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.dropItems.Name = "dropItems"
        Me.dropItems.Size = New System.Drawing.Size(29, 22)
        Me.dropItems.Text = "Add field"
        '
        'btInsertAt
        '
        Me.btInsertAt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btInsertAt.Image = CType(resources.GetObject("btInsertAt.Image"), System.Drawing.Image)
        Me.btInsertAt.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btInsertAt.Name = "btInsertAt"
        Me.btInsertAt.Size = New System.Drawing.Size(29, 22)
        Me.btInsertAt.Text = "Insert field at"
        '
        'btDelete
        '
        Me.btDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btDelete.Image = CType(resources.GetObject("btDelete.Image"), System.Drawing.Image)
        Me.btDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btDelete.Name = "btDelete"
        Me.btDelete.Size = New System.Drawing.Size(23, 22)
        Me.btDelete.Text = "Delete field"
        '
        'btClear
        '
        Me.btClear.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btClear.Image = CType(resources.GetObject("btClear.Image"), System.Drawing.Image)
        Me.btClear.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btClear.Name = "btClear"
        Me.btClear.Size = New System.Drawing.Size(23, 22)
        Me.btClear.Text = "Clear text"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'btMoveUp
        '
        Me.btMoveUp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btMoveUp.Image = CType(resources.GetObject("btMoveUp.Image"), System.Drawing.Image)
        Me.btMoveUp.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btMoveUp.Name = "btMoveUp"
        Me.btMoveUp.Size = New System.Drawing.Size(23, 22)
        Me.btMoveUp.Text = "Move up"
        '
        'btMoveDown
        '
        Me.btMoveDown.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btMoveDown.Image = CType(resources.GetObject("btMoveDown.Image"), System.Drawing.Image)
        Me.btMoveDown.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btMoveDown.Name = "btMoveDown"
        Me.btMoveDown.Size = New System.Drawing.Size(23, 22)
        Me.btMoveDown.Text = "Move down"
        '
        'ToolStripSeparator16
        '
        Me.ToolStripSeparator16.Name = "ToolStripSeparator16"
        Me.ToolStripSeparator16.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnExample1, Me.ToolStripSeparator5, Me.mnExample2, Me.ToolStripSeparator13, Me.mnExample3, Me.ToolStripSeparator14, Me.mnExample4})
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(29, 22)
        Me.ToolStripButton1.Text = "Example"
        '
        'mnExample1
        '
        Me.mnExample1.Name = "mnExample1"
        Me.mnExample1.Size = New System.Drawing.Size(127, 22)
        Me.mnExample1.Text = "Example 1"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(124, 6)
        '
        'mnExample2
        '
        Me.mnExample2.Name = "mnExample2"
        Me.mnExample2.Size = New System.Drawing.Size(127, 22)
        Me.mnExample2.Text = "Example 2"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(124, 6)
        '
        'mnExample3
        '
        Me.mnExample3.Name = "mnExample3"
        Me.mnExample3.Size = New System.Drawing.Size(127, 22)
        Me.mnExample3.Text = "Example 3"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(124, 6)
        '
        'mnExample4
        '
        Me.mnExample4.Name = "mnExample4"
        Me.mnExample4.Size = New System.Drawing.Size(127, 22)
        Me.mnExample4.Text = "Example 4"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'btReview
        '
        Me.btReview.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btReview.Image = CType(resources.GetObject("btReview.Image"), System.Drawing.Image)
        Me.btReview.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btReview.Name = "btReview"
        Me.btReview.Size = New System.Drawing.Size(23, 22)
        Me.btReview.Text = "Review"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(3, 31)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(762, 157)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.listEntry)
        Me.TabPage1.Location = New System.Drawing.Point(4, 26)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(754, 127)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Sense"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'listEntry
        '
        Me.listEntry.AllowUserToAddRows = False
        Me.listEntry.AllowUserToDeleteRows = False
        Me.listEntry.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.listEntry.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.listEntry.ColumnHeadersVisible = False
        Me.listEntry.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.checked, Me.Atrributes, Me.Text})
        Me.listEntry.Dock = System.Windows.Forms.DockStyle.Fill
        Me.listEntry.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.listEntry.Location = New System.Drawing.Point(3, 3)
        Me.listEntry.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.listEntry.MultiSelect = False
        Me.listEntry.Name = "listEntry"
        Me.listEntry.RowHeadersVisible = False
        Me.listEntry.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.listEntry.Size = New System.Drawing.Size(748, 121)
        Me.listEntry.TabIndex = 7
        '
        'checked
        '
        Me.checked.HeaderText = "checked"
        Me.checked.Name = "checked"
        Me.checked.Width = 30
        '
        'Atrributes
        '
        Me.Atrributes.HeaderText = "Atrributes"
        Me.Atrributes.Name = "Atrributes"
        Me.Atrributes.ReadOnly = True
        '
        'Text
        '
        Me.Text.HeaderText = "Text"
        Me.Text.Name = "Text"
        Me.Text.Width = 200
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 1
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.txtCode, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.ToolStrip2, 0, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 2
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(768, 264)
        Me.TableLayoutPanel3.TabIndex = 2
        '
        'txtCode
        '
        Me.txtCode.AutoCompleteBracketsList = New Char() {Global.Microsoft.VisualBasic.ChrW(40), Global.Microsoft.VisualBasic.ChrW(41), Global.Microsoft.VisualBasic.ChrW(123), Global.Microsoft.VisualBasic.ChrW(125), Global.Microsoft.VisualBasic.ChrW(91), Global.Microsoft.VisualBasic.ChrW(93), Global.Microsoft.VisualBasic.ChrW(34), Global.Microsoft.VisualBasic.ChrW(34), Global.Microsoft.VisualBasic.ChrW(39), Global.Microsoft.VisualBasic.ChrW(39)}
        Me.txtCode.AutoIndentCharsPatterns = ""
        Me.txtCode.AutoScrollMinSize = New System.Drawing.Size(0, 18)
        Me.txtCode.BackBrush = Nothing
        Me.txtCode.BackColor = System.Drawing.Color.Snow
        Me.txtCode.CharHeight = 18
        Me.txtCode.CharWidth = 10
        Me.txtCode.CommentPrefix = Nothing
        Me.txtCode.ContextMenuStrip = Me.menuOnText
        Me.txtCode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCode.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txtCode.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtCode.Font = New System.Drawing.Font("Courier New", 12.0!)
        Me.txtCode.ForeColor = System.Drawing.Color.DarkBlue
        Me.txtCode.IsReplaceMode = False
        Me.txtCode.Language = FastColoredTextBoxNS.Language.HTML
        Me.txtCode.LeftBracket = Global.Microsoft.VisualBasic.ChrW(60)
        Me.txtCode.LeftBracket2 = Global.Microsoft.VisualBasic.ChrW(40)
        Me.txtCode.Location = New System.Drawing.Point(2, 31)
        Me.txtCode.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txtCode.Name = "txtCode"
        Me.txtCode.Paddings = New System.Windows.Forms.Padding(0)
        Me.txtCode.RightBracket = Global.Microsoft.VisualBasic.ChrW(62)
        Me.txtCode.RightBracket2 = Global.Microsoft.VisualBasic.ChrW(41)
        Me.txtCode.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCode.ServiceColors = CType(resources.GetObject("txtCode.ServiceColors"), FastColoredTextBoxNS.ServiceColors)
        Me.txtCode.Size = New System.Drawing.Size(764, 230)
        Me.txtCode.TabIndex = 21
        Me.txtCode.WordWrap = True
        Me.txtCode.Zoom = 100
        '
        'menuOnText
        '
        Me.menuOnText.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.menuOnText.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnReview, Me.ToolStripSeparator11, Me.mnCut, Me.mnCopy, Me.mnPaste, Me.ToolStripSeparator15, Me.mnUpcase, Me.mnLowcase, Me.mnTittleCase, Me.ToolStripSeparator17, Me.mnJoinLines, Me.mnSplitLines, Me.ToolStripSeparator18, Me.mnTrimSpaces})
        Me.menuOnText.Name = "menuOnText"
        Me.menuOnText.Size = New System.Drawing.Size(148, 248)
        '
        'mnReview
        '
        Me.mnReview.Image = CType(resources.GetObject("mnReview.Image"), System.Drawing.Image)
        Me.mnReview.Name = "mnReview"
        Me.mnReview.Size = New System.Drawing.Size(147, 22)
        Me.mnReview.Text = "Preview result"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(144, 6)
        '
        'mnCut
        '
        Me.mnCut.Image = CType(resources.GetObject("mnCut.Image"), System.Drawing.Image)
        Me.mnCut.Name = "mnCut"
        Me.mnCut.Size = New System.Drawing.Size(147, 22)
        Me.mnCut.Text = "Cut"
        '
        'mnCopy
        '
        Me.mnCopy.Image = Global.Dictionary_Maker.My.Resources.Resources.Copy
        Me.mnCopy.Name = "mnCopy"
        Me.mnCopy.Size = New System.Drawing.Size(147, 22)
        Me.mnCopy.Text = "Copy"
        '
        'mnPaste
        '
        Me.mnPaste.Image = CType(resources.GetObject("mnPaste.Image"), System.Drawing.Image)
        Me.mnPaste.Name = "mnPaste"
        Me.mnPaste.Size = New System.Drawing.Size(147, 22)
        Me.mnPaste.Text = "Paste"
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(144, 6)
        '
        'mnUpcase
        '
        Me.mnUpcase.Image = CType(resources.GetObject("mnUpcase.Image"), System.Drawing.Image)
        Me.mnUpcase.Name = "mnUpcase"
        Me.mnUpcase.Size = New System.Drawing.Size(147, 22)
        Me.mnUpcase.Text = "UPCASE"
        '
        'mnLowcase
        '
        Me.mnLowcase.Image = CType(resources.GetObject("mnLowcase.Image"), System.Drawing.Image)
        Me.mnLowcase.Name = "mnLowcase"
        Me.mnLowcase.Size = New System.Drawing.Size(147, 22)
        Me.mnLowcase.Text = "lowcase"
        '
        'mnTittleCase
        '
        Me.mnTittleCase.Image = CType(resources.GetObject("mnTittleCase.Image"), System.Drawing.Image)
        Me.mnTittleCase.Name = "mnTittleCase"
        Me.mnTittleCase.Size = New System.Drawing.Size(147, 22)
        Me.mnTittleCase.Text = "Tittle Case"
        '
        'ToolStripSeparator17
        '
        Me.ToolStripSeparator17.Name = "ToolStripSeparator17"
        Me.ToolStripSeparator17.Size = New System.Drawing.Size(144, 6)
        '
        'mnJoinLines
        '
        Me.mnJoinLines.Image = CType(resources.GetObject("mnJoinLines.Image"), System.Drawing.Image)
        Me.mnJoinLines.Name = "mnJoinLines"
        Me.mnJoinLines.Size = New System.Drawing.Size(147, 22)
        Me.mnJoinLines.Text = "Join lines"
        '
        'mnSplitLines
        '
        Me.mnSplitLines.Image = CType(resources.GetObject("mnSplitLines.Image"), System.Drawing.Image)
        Me.mnSplitLines.Name = "mnSplitLines"
        Me.mnSplitLines.Size = New System.Drawing.Size(147, 22)
        Me.mnSplitLines.Text = "Split lines"
        '
        'ToolStripSeparator18
        '
        Me.ToolStripSeparator18.Name = "ToolStripSeparator18"
        Me.ToolStripSeparator18.Size = New System.Drawing.Size(144, 6)
        '
        'mnTrimSpaces
        '
        Me.mnTrimSpaces.Image = CType(resources.GetObject("mnTrimSpaces.Image"), System.Drawing.Image)
        Me.mnTrimSpaces.Name = "mnTrimSpaces"
        Me.mnTrimSpaces.Size = New System.Drawing.Size(147, 22)
        Me.mnTrimSpaces.Text = "Trim spaces"
        '
        'ToolStrip2
        '
        Me.ToolStrip2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btBack, Me.btNext, Me.ToolStripSeparator2, Me.btBold, Me.btItalic, Me.btUnderline, Me.ToolStripSeparator3, Me.btParaLeft, Me.btParaCenter, Me.btParaRight, Me.ToolStripSeparator4, Me.btUL1, Me.btOL1, Me.btLI1, Me.btLabel, Me.btSuperScript, Me.btLine, Me.btLink, Me.btuLNum, Me.btTable, Me.ToolStripSeparator6, Me.btColors, Me.btTextColors, Me.ToolStripSeparator7, Me.btClearFormating, Me.ToolStripSeparator9, Me.btReplace, Me.ToolStripSeparator12, Me.ToolStripLabel2, Me.cboSymbol, Me.btInsert})
        Me.ToolStrip2.Location = New System.Drawing.Point(2, 0)
        Me.ToolStrip2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(764, 25)
        Me.ToolStrip2.TabIndex = 20
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'btBack
        '
        Me.btBack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btBack.Image = CType(resources.GetObject("btBack.Image"), System.Drawing.Image)
        Me.btBack.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btBack.Name = "btBack"
        Me.btBack.Size = New System.Drawing.Size(23, 22)
        Me.btBack.Text = "ToolStripButton2"
        '
        'btNext
        '
        Me.btNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btNext.Image = CType(resources.GetObject("btNext.Image"), System.Drawing.Image)
        Me.btNext.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btNext.Name = "btNext"
        Me.btNext.Size = New System.Drawing.Size(23, 22)
        Me.btNext.Text = "ToolStripButton4"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'btBold
        '
        Me.btBold.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btBold.Image = Global.Dictionary_Maker.My.Resources.Resources.Bold
        Me.btBold.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btBold.Name = "btBold"
        Me.btBold.Size = New System.Drawing.Size(23, 22)
        Me.btBold.Text = "Bold"
        '
        'btItalic
        '
        Me.btItalic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btItalic.Image = Global.Dictionary_Maker.My.Resources.Resources.Italic
        Me.btItalic.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btItalic.Name = "btItalic"
        Me.btItalic.Size = New System.Drawing.Size(23, 22)
        Me.btItalic.Text = "Italic"
        '
        'btUnderline
        '
        Me.btUnderline.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btUnderline.Image = Global.Dictionary_Maker.My.Resources.Resources.Underline
        Me.btUnderline.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btUnderline.Name = "btUnderline"
        Me.btUnderline.Size = New System.Drawing.Size(23, 22)
        Me.btUnderline.Text = "Underline"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'btParaLeft
        '
        Me.btParaLeft.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btParaLeft.Image = Global.Dictionary_Maker.My.Resources.Resources.JustifyLeft
        Me.btParaLeft.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btParaLeft.Name = "btParaLeft"
        Me.btParaLeft.Size = New System.Drawing.Size(23, 22)
        Me.btParaLeft.Text = "Left"
        '
        'btParaCenter
        '
        Me.btParaCenter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btParaCenter.Image = Global.Dictionary_Maker.My.Resources.Resources.JustifyCenter
        Me.btParaCenter.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btParaCenter.Name = "btParaCenter"
        Me.btParaCenter.Size = New System.Drawing.Size(23, 22)
        Me.btParaCenter.Text = "Center"
        '
        'btParaRight
        '
        Me.btParaRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btParaRight.Image = Global.Dictionary_Maker.My.Resources.Resources.JustifyRight
        Me.btParaRight.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btParaRight.Name = "btParaRight"
        Me.btParaRight.Size = New System.Drawing.Size(23, 22)
        Me.btParaRight.Text = "Right"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'btUL1
        '
        Me.btUL1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btUL1.Image = CType(resources.GetObject("btUL1.Image"), System.Drawing.Image)
        Me.btUL1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btUL1.Name = "btUL1"
        Me.btUL1.Size = New System.Drawing.Size(25, 22)
        Me.btUL1.Text = "UL"
        '
        'btOL1
        '
        Me.btOL1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btOL1.Image = CType(resources.GetObject("btOL1.Image"), System.Drawing.Image)
        Me.btOL1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btOL1.Name = "btOL1"
        Me.btOL1.Size = New System.Drawing.Size(26, 22)
        Me.btOL1.Text = "OL"
        '
        'btLI1
        '
        Me.btLI1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btLI1.Image = CType(resources.GetObject("btLI1.Image"), System.Drawing.Image)
        Me.btLI1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btLI1.Name = "btLI1"
        Me.btLI1.Size = New System.Drawing.Size(23, 22)
        Me.btLI1.Text = "LI"
        '
        'btLabel
        '
        Me.btLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btLabel.Image = CType(resources.GetObject("btLabel.Image"), System.Drawing.Image)
        Me.btLabel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btLabel.Name = "btLabel"
        Me.btLabel.Size = New System.Drawing.Size(23, 22)
        Me.btLabel.Text = "Label tag"
        '
        'btSuperScript
        '
        Me.btSuperScript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btSuperScript.Image = CType(resources.GetObject("btSuperScript.Image"), System.Drawing.Image)
        Me.btSuperScript.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btSuperScript.Name = "btSuperScript"
        Me.btSuperScript.Size = New System.Drawing.Size(23, 22)
        Me.btSuperScript.Text = "SuperScript"
        '
        'btLine
        '
        Me.btLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btLine.Image = CType(resources.GetObject("btLine.Image"), System.Drawing.Image)
        Me.btLine.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btLine.Name = "btLine"
        Me.btLine.Size = New System.Drawing.Size(23, 22)
        Me.btLine.Text = "Line"
        '
        'btLink
        '
        Me.btLink.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btLink.Image = Global.Dictionary_Maker.My.Resources.Resources.CreateLink
        Me.btLink.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btLink.Name = "btLink"
        Me.btLink.Size = New System.Drawing.Size(23, 22)
        Me.btLink.Text = "Link"
        '
        'btuLNum
        '
        Me.btuLNum.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btuLNum.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem6, Me.IIIIIIToolStripMenuItem, Me.ABCToolStripMenuItem})
        Me.btuLNum.Image = Global.Dictionary_Maker.My.Resources.Resources.InsertOrderedList
        Me.btuLNum.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btuLNum.Name = "btuLNum"
        Me.btuLNum.Size = New System.Drawing.Size(29, 22)
        Me.btuLNum.Text = "Numbering"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(108, 22)
        Me.ToolStripMenuItem6.Text = "1,2,3..."
        '
        'IIIIIIToolStripMenuItem
        '
        Me.IIIIIIToolStripMenuItem.Name = "IIIIIIToolStripMenuItem"
        Me.IIIIIIToolStripMenuItem.Size = New System.Drawing.Size(108, 22)
        Me.IIIIIIToolStripMenuItem.Text = "I,II,III..."
        '
        'ABCToolStripMenuItem
        '
        Me.ABCToolStripMenuItem.Name = "ABCToolStripMenuItem"
        Me.ABCToolStripMenuItem.Size = New System.Drawing.Size(108, 22)
        Me.ABCToolStripMenuItem.Text = "a,b,c..."
        '
        'btTable
        '
        Me.btTable.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btTable.Image = CType(resources.GetObject("btTable.Image"), System.Drawing.Image)
        Me.btTable.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btTable.Name = "btTable"
        Me.btTable.Size = New System.Drawing.Size(23, 22)
        Me.btTable.Text = "ToolStripButton2"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'btColors
        '
        Me.btColors.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btColors.Image = CType(resources.GetObject("btColors.Image"), System.Drawing.Image)
        Me.btColors.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btColors.Name = "btColors"
        Me.btColors.Size = New System.Drawing.Size(23, 22)
        Me.btColors.Text = "Text colors"
        '
        'btTextColors
        '
        Me.btTextColors.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btTextColors.Image = CType(resources.GetObject("btTextColors.Image"), System.Drawing.Image)
        Me.btTextColors.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btTextColors.Name = "btTextColors"
        Me.btTextColors.Size = New System.Drawing.Size(23, 22)
        Me.btTextColors.Text = "Background colors"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'btClearFormating
        '
        Me.btClearFormating.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btClearFormating.Image = Global.Dictionary_Maker.My.Resources.Resources.RemoveFormat
        Me.btClearFormating.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btClearFormating.Name = "btClearFormating"
        Me.btClearFormating.Size = New System.Drawing.Size(23, 22)
        Me.btClearFormating.Text = "Clear tag"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'btReplace
        '
        Me.btReplace.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btReplace.Image = CType(resources.GetObject("btReplace.Image"), System.Drawing.Image)
        Me.btReplace.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btReplace.Name = "btReplace"
        Me.btReplace.Size = New System.Drawing.Size(23, 22)
        Me.btReplace.Text = "Find and Replace"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(52, 22)
        Me.ToolStripLabel2.Text = "Symbols"
        '
        'cboSymbol
        '
        Me.cboSymbol.Items.AddRange(New Object() {"►", "□", "♦", "●", "→", "§", "√", "ǁ", "—–", "‣", "▪", "←"})
        Me.cboSymbol.Name = "cboSymbol"
        Me.cboSymbol.Size = New System.Drawing.Size(75, 25)
        Me.cboSymbol.Text = "►"
        '
        'btInsert
        '
        Me.btInsert.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btInsert.Image = CType(resources.GetObject("btInsert.Image"), System.Drawing.Image)
        Me.btInsert.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btInsert.Name = "btInsert"
        Me.btInsert.Size = New System.Drawing.Size(23, 22)
        Me.btInsert.Text = "ToolStripButton2"
        '
        'frmEntry2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(768, 458)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HideOnClose = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "frmEntry2"
        Me.ShowInTaskbar = False
        Me.TabText = "New Entry"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.listEntry, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        CType(Me.txtCode, System.ComponentModel.ISupportInitialize).EndInit()
        Me.menuOnText.ResumeLayout(False)
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents dropItems As ToolStripDropDownButton
    Friend WithEvents btDelete As ToolStripButton
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents txtCode As FastColoredTextBoxNS.FastColoredTextBox
    Friend WithEvents ToolStrip2 As ToolStrip
    Friend WithEvents btBold As ToolStripButton
    Friend WithEvents btItalic As ToolStripButton
    Friend WithEvents btUnderline As ToolStripButton
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents btParaLeft As ToolStripButton
    Friend WithEvents btParaCenter As ToolStripButton
    Friend WithEvents btParaRight As ToolStripButton
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents btLink As ToolStripButton
    Friend WithEvents btSuperScript As ToolStripButton
    Friend WithEvents btLine As ToolStripButton
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents btColors As ToolStripButton
    Friend WithEvents btTextColors As ToolStripButton
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents btClearFormating As ToolStripButton
    Friend WithEvents ToolStripSeparator9 As ToolStripSeparator
    Friend WithEvents btReplace As ToolStripButton
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents listEntry As DataGridView
    Friend WithEvents Text1 As DataGridViewTextBoxColumn
    Friend WithEvents btNewEntry As ToolStripButton
    Friend WithEvents ToolStripSeparator10 As ToolStripSeparator
    Friend WithEvents btComplete As ToolStripButton
    Friend WithEvents btBack As ToolStripButton
    Friend WithEvents btNext As ToolStripButton
    Friend WithEvents colorsText As ColorDialog
    Friend WithEvents btUL1 As ToolStripButton
    Friend WithEvents btOL1 As ToolStripButton
    Friend WithEvents btLI1 As ToolStripButton
    Friend WithEvents btuLNum As ToolStripDropDownButton
    Friend WithEvents ToolStripMenuItem6 As ToolStripMenuItem
    Friend WithEvents IIIIIIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ABCToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btLabel As ToolStripButton
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripButton1 As ToolStripDropDownButton
    Friend WithEvents btReview As ToolStripButton
    Friend WithEvents mnExample1 As ToolStripMenuItem
    Friend WithEvents btClear As ToolStripButton
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents cboStatus As ToolStripComboBox
    Friend WithEvents backgroudBuildCode As System.ComponentModel.BackgroundWorker
    Friend WithEvents ToolStripSeparator8 As ToolStripSeparator
    Friend WithEvents menuOnText As ContextMenuStrip
    Friend WithEvents mnReview As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator11 As ToolStripSeparator
    Friend WithEvents mnCut As ToolStripMenuItem
    Friend WithEvents mnCopy As ToolStripMenuItem
    Friend WithEvents mnPaste As ToolStripMenuItem
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cboSymbol As ToolStripComboBox
    Friend WithEvents ToolStripSeparator12 As ToolStripSeparator
    Friend WithEvents btInsert As ToolStripButton
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents mnExample2 As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator13 As ToolStripSeparator
    Friend WithEvents mnExample3 As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator14 As ToolStripSeparator
    Friend WithEvents mnExample4 As ToolStripMenuItem
    Friend WithEvents btTable As ToolStripButton
    Friend WithEvents ToolStripSeparator15 As ToolStripSeparator
    Friend WithEvents mnUpcase As ToolStripMenuItem
    Friend WithEvents mnLowcase As ToolStripMenuItem
    Friend WithEvents mnTittleCase As ToolStripMenuItem
    Friend WithEvents btMoveUp As ToolStripButton
    Friend WithEvents btMoveDown As ToolStripButton
    Friend WithEvents ToolStripSeparator16 As ToolStripSeparator
    Friend WithEvents btInsertAt As ToolStripDropDownButton
    Friend WithEvents checked As DataGridViewCheckBoxColumn
    Friend WithEvents Atrributes As DataGridViewTextBoxColumn
    Friend WithEvents Text As DataGridViewTextBoxColumn
    Friend WithEvents ToolStripSeparator17 As ToolStripSeparator
    Friend WithEvents mnJoinLines As ToolStripMenuItem
    Friend WithEvents mnSplitLines As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator18 As ToolStripSeparator
    Friend WithEvents mnTrimSpaces As ToolStripMenuItem
End Class
