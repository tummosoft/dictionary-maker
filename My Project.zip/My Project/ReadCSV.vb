﻿Imports System
Imports FileHelpers

<DelimitedRecord("")>
Public Class PaliAutocomplete
    <FieldQuoted>
    Public Unicode As String
End Class

<DelimitedRecord("")>
Public Class ImprotCSV1Row
    <FieldQuoted>
    Public row1 As String
End Class

<DelimitedRecord("|")>
Public Class ImprotCSV2Row
    <FieldQuoted>
    Public row1 As String
    <FieldQuoted>
    Public row2 As String
End Class

<DelimitedRecord("|")>
Public Class ImprotCSV3Row
    <FieldQuoted>
    Public row1 As String
    <FieldQuoted>
    Public row2 As String
    <FieldQuoted>
    Public row3 As String
End Class

<DelimitedRecord("|")>
Public Class ImprotCSV4Row
    <FieldQuoted>
    Public row1 As String
    <FieldQuoted>
    Public row2 As String
    <FieldQuoted>
    Public row3 As String
    <FieldQuoted>
    Public row4 As String
End Class

<DelimitedRecord("|")>
Public Class ImprotCSV5Row
    <FieldQuoted>
    Public row1 As String
    <FieldQuoted>
    Public row2 As String
    <FieldQuoted>
    Public row3 As String
    <FieldQuoted>
    Public row4 As String
    <FieldQuoted>
    Public row5 As String
End Class

<DelimitedRecord("|")>
Public Class ImprotCSV6Row
    <FieldQuoted>
    Public row1 As String
    <FieldQuoted>
    Public row2 As String
    <FieldQuoted>
    Public row3 As String
    <FieldQuoted>
    Public row4 As String
    <FieldQuoted>
    Public row5 As String
    <FieldQuoted>
    Public row6 As String
End Class

<DelimitedRecord("|")>
Public Class ImprotCSV7Row
    <FieldQuoted>
    Public row1 As String
    <FieldQuoted>
    Public row2 As String
    <FieldQuoted>
    Public row3 As String
    <FieldQuoted>
    Public row4 As String
    <FieldQuoted>
    Public row5 As String
    <FieldQuoted>
    Public row6 As String
    <FieldQuoted>
    Public row7 As String
End Class