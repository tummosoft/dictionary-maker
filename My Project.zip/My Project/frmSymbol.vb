﻿Imports WeifenLuo.WinFormsUI.Docking
Partial Public Class frmSymbol
    Inherits DockContent
    Private Sub TableLayoutPanel1_Paint(sender As Object, e As PaintEventArgs) Handles TableLayoutPanel1.Paint

    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Clipboard.SetText(Button10.Text)
        'frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Clipboard.SetText(Button6.Text)
        'frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Clipboard.SetText(Button2.Text)
        'frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Clipboard.SetText(Button8.Text)
        'frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Clipboard.SetText(Button4.Text)
        ' frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Clipboard.SetText(Button1.Text)
        'frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Clipboard.SetText(Button7.Text)
        ' frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Clipboard.SetText(Button11.Text)
        'frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Clipboard.SetText(Button3.Text)
        'frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Clipboard.SetText(Button2.Text)
        ' frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Clipboard.SetText(Button9.Text)
        'frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Clipboard.SetText(Button5.Text)
        ' frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        Clipboard.SetText(Button15.Text)
        'frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Clipboard.SetText(Button14.Text)
        ' frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Clipboard.SetText(Button13.Text)
        'frmMDI.frmInput.CurrentTextbox.Paste()
    End Sub
End Class