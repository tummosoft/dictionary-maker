﻿Module mUniform
    Public PackageDict As Integer ' 0: Pali-English; 1: English - Pali; 2 - Pali -Viet; 3 Viet - Plai; 4 - Pali-Chinese
    Public PackageTable As String
    Public PackShortName As String
    Public PackLongName As String
    Public CSSFile As String
    Public ProjectName As String
    Public ProjectTable As String
    Public SourceLanguage As String
    Public TargetLanguage As String
    Public EntryReady As Boolean
    Public _word As String
    Public txtCodeActive As Boolean
    Public StyleCSS As String
    Public AndNewAtributesMode As Integer
    Public TableCode As String
End Module
