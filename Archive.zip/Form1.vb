﻿

Public Class Form1
    Dim build1 As New BuildCode
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'build1.BuildField()
    End Sub
End Class