﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.ToolStripContainer1 = New System.Windows.Forms.ToolStripContainer()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.tabList = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me._tableEntry = New System.Windows.Forms.TableLayoutPanel()
        Me._tableEntryButton = New System.Windows.Forms.TableLayoutPanel()
        Me.btNewEntry = New ComponentFactory.Krypton.Toolkit.KryptonButton()
        Me.btDeleteEntry = New ComponentFactory.Krypton.Toolkit.KryptonButton()
        Me.txtSearchEntry = New ComponentFactory.Krypton.Toolkit.KryptonTextBox()
        Me.listWord = New ComponentFactory.Krypton.Toolkit.KryptonListBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.listSearch = New System.Windows.Forms.ListBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.img16 = New System.Windows.Forms.ImageList(Me.components)
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.tabEdit = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtWord = New ComponentFactory.Krypton.Toolkit.KryptonTextBox()
        Me.txtPronounciation = New ComponentFactory.Krypton.Toolkit.KryptonTextBox()
        Me.txtDerive = New ComponentFactory.Krypton.Toolkit.KryptonTextBox()
        Me.ButtonSpecAny1 = New ComponentFactory.Krypton.Toolkit.ButtonSpecAny()
        Me.contextDerive = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtEtymology = New ComponentFactory.Krypton.Toolkit.KryptonTextBox()
        Me.ButtonSpecAny2 = New ComponentFactory.Krypton.Toolkit.ButtonSpecAny()
        Me.contextEtymo = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.btBold = New System.Windows.Forms.ToolStripButton()
        Me.btItalic = New System.Windows.Forms.ToolStripButton()
        Me.btUnderline = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton14 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton15 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton16 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton17 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton18 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton22 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton19 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton25 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton20 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton21 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton26 = New System.Windows.Forms.ToolStripButton()
        Me.btTable = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.btColors = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton23 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton24 = New System.Windows.Forms.ToolStripButton()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.txtCode = New FastColoredTextBoxNS.FastColoredTextBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.gridAttributes = New System.Windows.Forms.DataGridView()
        Me.colAtt = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.colText = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me._tableResult = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btOpen = New System.Windows.Forms.ToolStripButton()
        Me.btSave = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton9 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton10 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton11 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton12 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripDropDownButton1 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton13 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripContainer1.BottomToolStripPanel.SuspendLayout()
        Me.ToolStripContainer1.ContentPanel.SuspendLayout()
        Me.ToolStripContainer1.TopToolStripPanel.SuspendLayout()
        Me.ToolStripContainer1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.tabList.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me._tableEntry.SuspendLayout()
        Me._tableEntryButton.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.tabEdit.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.contextDerive.SuspendLayout()
        Me.contextEtymo.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        CType(Me.txtCode, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.gridAttributes, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._tableResult.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStripContainer1
        '
        '
        'ToolStripContainer1.BottomToolStripPanel
        '
        Me.ToolStripContainer1.BottomToolStripPanel.Controls.Add(Me.StatusStrip1)
        '
        'ToolStripContainer1.ContentPanel
        '
        Me.ToolStripContainer1.ContentPanel.Controls.Add(Me.SplitContainer1)
        Me.ToolStripContainer1.ContentPanel.Margin = New System.Windows.Forms.Padding(4)
        Me.ToolStripContainer1.ContentPanel.Size = New System.Drawing.Size(908, 343)
        Me.ToolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ToolStripContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripContainer1.Margin = New System.Windows.Forms.Padding(4)
        Me.ToolStripContainer1.Name = "ToolStripContainer1"
        Me.ToolStripContainer1.Size = New System.Drawing.Size(908, 414)
        Me.ToolStripContainer1.TabIndex = 0
        Me.ToolStripContainer1.Text = "ToolStripContainer1"
        '
        'ToolStripContainer1.TopToolStripPanel
        '
        Me.ToolStripContainer1.TopToolStripPanel.Controls.Add(Me.MenuStrip1)
        Me.ToolStripContainer1.TopToolStripPanel.Controls.Add(Me.ToolStrip1)
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 0)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(908, 22)
        Me.StatusStrip1.TabIndex = 0
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(36, 17)
        Me.ToolStripStatusLabel1.Text = "Total:"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Margin = New System.Windows.Forms.Padding(4, 10, 4, 4)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.tabList)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(908, 343)
        Me.SplitContainer1.SplitterDistance = 155
        Me.SplitContainer1.SplitterWidth = 5
        Me.SplitContainer1.TabIndex = 0
        '
        'tabList
        '
        Me.tabList.Controls.Add(Me.TabPage1)
        Me.tabList.Controls.Add(Me.TabPage2)
        Me.tabList.Controls.Add(Me.TabPage5)
        Me.tabList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabList.ImageList = Me.img16
        Me.tabList.Location = New System.Drawing.Point(0, 0)
        Me.tabList.Name = "tabList"
        Me.tabList.Padding = New System.Drawing.Point(5, 5)
        Me.tabList.SelectedIndex = 0
        Me.tabList.Size = New System.Drawing.Size(155, 343)
        Me.tabList.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me._tableEntry)
        Me.TabPage1.ImageIndex = 9
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Size = New System.Drawing.Size(147, 310)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Entries"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        '_tableEntry
        '
        Me._tableEntry.ColumnCount = 1
        Me._tableEntry.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me._tableEntry.Controls.Add(Me._tableEntryButton, 0, 0)
        Me._tableEntry.Controls.Add(Me.txtSearchEntry, 0, 1)
        Me._tableEntry.Controls.Add(Me.listWord, 0, 2)
        Me._tableEntry.Dock = System.Windows.Forms.DockStyle.Fill
        Me._tableEntry.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._tableEntry.Location = New System.Drawing.Point(4, 4)
        Me._tableEntry.Name = "_tableEntry"
        Me._tableEntry.RowCount = 3
        Me._tableEntry.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me._tableEntry.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me._tableEntry.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me._tableEntry.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me._tableEntry.Size = New System.Drawing.Size(139, 302)
        Me._tableEntry.TabIndex = 1
        '
        '_tableEntryButton
        '
        Me._tableEntryButton.ColumnCount = 1
        Me._tableEntryButton.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me._tableEntryButton.Controls.Add(Me.btNewEntry, 0, 0)
        Me._tableEntryButton.Controls.Add(Me.btDeleteEntry, 0, 1)
        Me._tableEntryButton.Dock = System.Windows.Forms.DockStyle.Fill
        Me._tableEntryButton.Location = New System.Drawing.Point(3, 3)
        Me._tableEntryButton.Name = "_tableEntryButton"
        Me._tableEntryButton.RowCount = 2
        Me._tableEntryButton.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me._tableEntryButton.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me._tableEntryButton.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me._tableEntryButton.Size = New System.Drawing.Size(195, 69)
        Me._tableEntryButton.TabIndex = 9
        '
        'btNewEntry
        '
        Me.btNewEntry.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btNewEntry.Location = New System.Drawing.Point(3, 3)
        Me.btNewEntry.Name = "btNewEntry"
        Me.btNewEntry.Size = New System.Drawing.Size(189, 29)
        Me.btNewEntry.TabIndex = 0
        Me.btNewEntry.Values.Text = "New Entry"
        '
        'btDeleteEntry
        '
        Me.btDeleteEntry.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btDeleteEntry.Location = New System.Drawing.Point(3, 38)
        Me.btDeleteEntry.Name = "btDeleteEntry"
        Me.btDeleteEntry.Size = New System.Drawing.Size(189, 29)
        Me.btDeleteEntry.TabIndex = 0
        Me.btDeleteEntry.Values.Text = "Delete Entry"
        '
        'txtSearchEntry
        '
        Me.txtSearchEntry.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtSearchEntry.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchEntry.Location = New System.Drawing.Point(5, 80)
        Me.txtSearchEntry.Margin = New System.Windows.Forms.Padding(5, 5, 7, 4)
        Me.txtSearchEntry.Name = "txtSearchEntry"
        Me.txtSearchEntry.Size = New System.Drawing.Size(189, 23)
        Me.txtSearchEntry.TabIndex = 0
        '
        'listWord
        '
        Me.listWord.Dock = System.Windows.Forms.DockStyle.Fill
        Me.listWord.Location = New System.Drawing.Point(5, 110)
        Me.listWord.Margin = New System.Windows.Forms.Padding(5, 10, 7, 3)
        Me.listWord.Name = "listWord"
        Me.listWord.Size = New System.Drawing.Size(189, 200)
        Me.listWord.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.listSearch)
        Me.TabPage2.ImageIndex = 10
        Me.TabPage2.Location = New System.Drawing.Point(4, 27)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage2.Size = New System.Drawing.Size(147, 312)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Dictionary"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'listSearch
        '
        Me.listSearch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.listSearch.FormattingEnabled = True
        Me.listSearch.ItemHeight = 16
        Me.listSearch.Location = New System.Drawing.Point(4, 4)
        Me.listSearch.Margin = New System.Windows.Forms.Padding(4)
        Me.listSearch.Name = "listSearch"
        Me.listSearch.Size = New System.Drawing.Size(139, 304)
        Me.listSearch.TabIndex = 2
        '
        'TabPage5
        '
        Me.TabPage5.ImageIndex = 11
        Me.TabPage5.Location = New System.Drawing.Point(4, 27)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(147, 312)
        Me.TabPage5.TabIndex = 2
        Me.TabPage5.Text = "Index"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'img16
        '
        Me.img16.ImageStream = CType(resources.GetObject("img16.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.img16.TransparentColor = System.Drawing.Color.Transparent
        Me.img16.Images.SetKeyName(0, "ic_border_color_black_18dp.png")
        Me.img16.Images.SetKeyName(1, "ic_settings_black_18dp.png")
        Me.img16.Images.SetKeyName(2, "ic_pageview_black_18dp.png")
        Me.img16.Images.SetKeyName(3, "flag_new.png")
        Me.img16.Images.SetKeyName(4, "flag_flyaway_orange.png")
        Me.img16.Images.SetKeyName(5, "tick_red.png")
        Me.img16.Images.SetKeyName(6, "new.png")
        Me.img16.Images.SetKeyName(7, "ic_code_black_18dp.png")
        Me.img16.Images.SetKeyName(8, "ic_format_paint_black_18dp.png")
        Me.img16.Images.SetKeyName(9, "document_editing.png")
        Me.img16.Images.SetKeyName(10, "research.png")
        Me.img16.Images.SetKeyName(11, "books_infront.png")
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Margin = New System.Windows.Forms.Padding(4)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.tabEdit)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me._tableResult)
        Me.SplitContainer2.Size = New System.Drawing.Size(748, 343)
        Me.SplitContainer2.SplitterDistance = 610
        Me.SplitContainer2.SplitterWidth = 5
        Me.SplitContainer2.TabIndex = 0
        '
        'tabEdit
        '
        Me.tabEdit.Controls.Add(Me.TabPage3)
        Me.tabEdit.Controls.Add(Me.TabPage4)
        Me.tabEdit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabEdit.ImageList = Me.img16
        Me.tabEdit.Location = New System.Drawing.Point(0, 0)
        Me.tabEdit.Name = "tabEdit"
        Me.tabEdit.SelectedIndex = 0
        Me.tabEdit.Size = New System.Drawing.Size(610, 343)
        Me.tabEdit.TabIndex = 1
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.TableLayoutPanel2)
        Me.TabPage3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.TabPage3.ImageIndex = 0
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(602, 314)
        Me.TabPage3.TabIndex = 0
        Me.TabPage3.Text = "Lemma (F1)"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label8, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.txtWord, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.txtPronounciation, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtDerive, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEtymology, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label4, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label3, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.ToolStrip2, 1, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.TabControl2, 1, 5)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 6
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(596, 308)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label8.Location = New System.Drawing.Point(3, 100)
        Me.Label8.Name = "Label8"
        Me.Label8.Padding = New System.Windows.Forms.Padding(0, 5, 0, 0)
        Me.Label8.Size = New System.Drawing.Size(94, 30)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Content"
        '
        'txtWord
        '
        Me.txtWord.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtWord.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWord.Location = New System.Drawing.Point(100, 0)
        Me.txtWord.Margin = New System.Windows.Forms.Padding(0)
        Me.txtWord.Name = "txtSearchEntry"
        Me.txtWord.Size = New System.Drawing.Size(496, 23)
        Me.txtWord.TabIndex = 0
        '
        'txtPronounciation
        '
        Me.txtPronounciation.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtPronounciation.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPronounciation.Location = New System.Drawing.Point(100, 25)
        Me.txtPronounciation.Margin = New System.Windows.Forms.Padding(0)
        Me.txtPronounciation.Name = "txtSearchEntry"
        Me.txtPronounciation.Size = New System.Drawing.Size(496, 23)
        Me.txtPronounciation.TabIndex = 0
        '
        'txtDerive
        '
        Me.txtDerive.ButtonSpecs.AddRange(New ComponentFactory.Krypton.Toolkit.ButtonSpecAny() {Me.ButtonSpecAny1})
        Me.txtDerive.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtDerive.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDerive.Location = New System.Drawing.Point(100, 50)
        Me.txtDerive.Margin = New System.Windows.Forms.Padding(0)
        Me.txtDerive.Name = "txtSearchEntry"
        Me.txtDerive.Size = New System.Drawing.Size(496, 23)
        Me.txtDerive.TabIndex = 0
        '
        'ButtonSpecAny1
        '
        Me.ButtonSpecAny1.ContextMenuStrip = Me.contextDerive
        Me.ButtonSpecAny1.Style = ComponentFactory.Krypton.Toolkit.PaletteButtonStyle.Standalone
        Me.ButtonSpecAny1.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.Context
        Me.ButtonSpecAny1.UniqueName = "B611C8E3DFC74F2393B030B4D9F4D600"
        '
        'contextDerive
        '
        Me.contextDerive.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.contextDerive.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.ToolStripMenuItem2, Me.ToolStripMenuItem3, Me.ToolStripMenuItem4})
        Me.contextDerive.Name = "contextDerive"
        Me.contextDerive.Size = New System.Drawing.Size(149, 92)
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem1.Text = "V: Vietnamese"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem2.Text = "E: English"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem3.Text = "C: Chinese"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem4.Text = "J: Japanses"
        '
        'txtEtymology
        '
        Me.txtEtymology.ButtonSpecs.AddRange(New ComponentFactory.Krypton.Toolkit.ButtonSpecAny() {Me.ButtonSpecAny2})
        Me.txtEtymology.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtEtymology.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEtymology.Location = New System.Drawing.Point(100, 75)
        Me.txtEtymology.Margin = New System.Windows.Forms.Padding(0)
        Me.txtEtymology.Name = "txtSearchEntry"
        Me.txtEtymology.Size = New System.Drawing.Size(496, 23)
        Me.txtEtymology.TabIndex = 0
        '
        'ButtonSpecAny2
        '
        Me.ButtonSpecAny2.ContextMenuStrip = Me.contextEtymo
        Me.ButtonSpecAny2.Style = ComponentFactory.Krypton.Toolkit.PaletteButtonStyle.Standalone
        Me.ButtonSpecAny2.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.Context
        Me.ButtonSpecAny2.UniqueName = "B6FB83188F0E4C0690BD045314F7A354"
        '
        'contextEtymo
        '
        Me.contextEtymo.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.contextEtymo.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem5, Me.ToolStripMenuItem6})
        Me.contextEtymo.Name = "contextDerive"
        Me.contextEtymo.Size = New System.Drawing.Size(116, 48)
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Checked = True
        Me.ToolStripMenuItem5.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(115, 22)
        Me.ToolStripMenuItem5.Text = "= (root)"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(115, 22)
        Me.ToolStripMenuItem6.Text = "root"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Location = New System.Drawing.Point(3, 75)
        Me.Label4.Name = "Label4"
        Me.Label4.Padding = New System.Windows.Forms.Padding(0, 5, 0, 0)
        Me.Label4.Size = New System.Drawing.Size(94, 25)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Etymology"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label3.Location = New System.Drawing.Point(3, 50)
        Me.Label3.Name = "Label3"
        Me.Label3.Padding = New System.Windows.Forms.Padding(0, 5, 0, 0)
        Me.Label3.Size = New System.Drawing.Size(94, 25)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Derive"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label2.Location = New System.Drawing.Point(3, 25)
        Me.Label2.Name = "Label2"
        Me.Label2.Padding = New System.Windows.Forms.Padding(0, 5, 0, 0)
        Me.Label2.Size = New System.Drawing.Size(94, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Pronunciation"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label1.Location = New System.Drawing.Point(3, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Padding = New System.Windows.Forms.Padding(0, 5, 0, 0)
        Me.Label1.Size = New System.Drawing.Size(94, 25)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Word"
        '
        'ToolStrip2
        '
        Me.ToolStrip2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btBold, Me.btItalic, Me.btUnderline, Me.ToolStripSeparator3, Me.ToolStripButton14, Me.ToolStripButton15, Me.ToolStripButton16, Me.ToolStripSeparator4, Me.ToolStripButton17, Me.ToolStripButton18, Me.ToolStripButton22, Me.ToolStripButton19, Me.ToolStripSeparator5, Me.ToolStripButton25, Me.ToolStripButton20, Me.ToolStripButton21, Me.ToolStripButton26, Me.btTable, Me.ToolStripSeparator6, Me.btColors, Me.ToolStripButton23, Me.ToolStripSeparator7, Me.ToolStripButton24})
        Me.ToolStrip2.Location = New System.Drawing.Point(103, 105)
        Me.ToolStrip2.Margin = New System.Windows.Forms.Padding(3, 5, 3, 0)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(490, 25)
        Me.ToolStrip2.TabIndex = 18
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'btBold
        '
        Me.btBold.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btBold.Image = Global.Dictionary_Maker.My.Resources.Resources.Bold
        Me.btBold.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btBold.Name = "btBold"
        Me.btBold.Size = New System.Drawing.Size(23, 22)
        Me.btBold.Text = "ToolStripButton14"
        '
        'btItalic
        '
        Me.btItalic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btItalic.Image = Global.Dictionary_Maker.My.Resources.Resources.Italic
        Me.btItalic.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btItalic.Name = "btItalic"
        Me.btItalic.Size = New System.Drawing.Size(23, 22)
        Me.btItalic.Text = "ToolStripButton14"
        '
        'btUnderline
        '
        Me.btUnderline.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btUnderline.Image = Global.Dictionary_Maker.My.Resources.Resources.Underline
        Me.btUnderline.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btUnderline.Name = "btUnderline"
        Me.btUnderline.Size = New System.Drawing.Size(23, 22)
        Me.btUnderline.Text = "ToolStripButton14"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton14
        '
        Me.ToolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton14.Image = Global.Dictionary_Maker.My.Resources.Resources.JustifyLeft
        Me.ToolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton14.Name = "ToolStripButton14"
        Me.ToolStripButton14.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton14.Text = "ToolStripButton14"
        '
        'ToolStripButton15
        '
        Me.ToolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton15.Image = Global.Dictionary_Maker.My.Resources.Resources.JustifyCenter
        Me.ToolStripButton15.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton15.Name = "ToolStripButton15"
        Me.ToolStripButton15.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton15.Text = "ToolStripButton15"
        '
        'ToolStripButton16
        '
        Me.ToolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton16.Image = Global.Dictionary_Maker.My.Resources.Resources.JustifyRight
        Me.ToolStripButton16.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton16.Name = "ToolStripButton16"
        Me.ToolStripButton16.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton16.Text = "ToolStripButton16"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton17
        '
        Me.ToolStripButton17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton17.Image = Global.Dictionary_Maker.My.Resources.Resources.InsertUnorderedList
        Me.ToolStripButton17.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton17.Name = "ToolStripButton17"
        Me.ToolStripButton17.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton17.Text = "ToolStripButton17"
        '
        'ToolStripButton18
        '
        Me.ToolStripButton18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton18.Image = Global.Dictionary_Maker.My.Resources.Resources.InsertOrderedList
        Me.ToolStripButton18.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton18.Name = "ToolStripButton18"
        Me.ToolStripButton18.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton18.Text = "ToolStripButton18"
        '
        'ToolStripButton22
        '
        Me.ToolStripButton22.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton22.Image = Global.Dictionary_Maker.My.Resources.Resources.Indent
        Me.ToolStripButton22.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton22.Name = "ToolStripButton22"
        Me.ToolStripButton22.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton22.Text = "ToolStripButton22"
        '
        'ToolStripButton19
        '
        Me.ToolStripButton19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton19.Image = Global.Dictionary_Maker.My.Resources.Resources.Outdent
        Me.ToolStripButton19.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton19.Name = "ToolStripButton19"
        Me.ToolStripButton19.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton19.Text = "ToolStripButton19"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton25
        '
        Me.ToolStripButton25.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton25.Image = Global.Dictionary_Maker.My.Resources.Resources.CreateLink
        Me.ToolStripButton25.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton25.Name = "ToolStripButton25"
        Me.ToolStripButton25.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton25.Text = "ToolStripButton25"
        '
        'ToolStripButton20
        '
        Me.ToolStripButton20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton20.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton20.Name = "ToolStripButton20"
        Me.ToolStripButton20.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton20.Text = "ToolStripButton20"
        '
        'ToolStripButton21
        '
        Me.ToolStripButton21.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton21.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton21.Name = "ToolStripButton21"
        Me.ToolStripButton21.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton21.Text = "ToolStripButton21"
        '
        'ToolStripButton26
        '
        Me.ToolStripButton26.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton26.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton26.Name = "ToolStripButton26"
        Me.ToolStripButton26.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton26.Text = "ToolStripButton26"
        '
        'btTable
        '
        Me.btTable.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btTable.Image = Global.Dictionary_Maker.My.Resources.Resources.InsertTable
        Me.btTable.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btTable.Name = "btTable"
        Me.btTable.Size = New System.Drawing.Size(23, 22)
        Me.btTable.Text = "ToolStripButton14"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'btColors
        '
        Me.btColors.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btColors.Image = Global.Dictionary_Maker.My.Resources.Resources.BackColor
        Me.btColors.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btColors.Name = "btColors"
        Me.btColors.Size = New System.Drawing.Size(23, 22)
        Me.btColors.Text = "ToolStripButton14"
        '
        'ToolStripButton23
        '
        Me.ToolStripButton23.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton23.Image = Global.Dictionary_Maker.My.Resources.Resources.ForeColor
        Me.ToolStripButton23.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton23.Name = "ToolStripButton23"
        Me.ToolStripButton23.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton23.Text = "ToolStripButton23"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton24
        '
        Me.ToolStripButton24.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton24.Image = Global.Dictionary_Maker.My.Resources.Resources.RemoveFormat
        Me.ToolStripButton24.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton24.Name = "ToolStripButton24"
        Me.ToolStripButton24.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton24.Text = "ToolStripButton24"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage8)
        Me.TabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl2.ImageList = Me.img16
        Me.TabControl2.Location = New System.Drawing.Point(103, 133)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(490, 174)
        Me.TabControl2.TabIndex = 21
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.txtCode)
        Me.TabPage8.ImageIndex = 7
        Me.TabPage8.Location = New System.Drawing.Point(4, 25)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(482, 145)
        Me.TabPage8.TabIndex = 1
        Me.TabPage8.Text = "Code"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'txtCode
        '
        Me.txtCode.AutoCompleteBracketsList = New Char() {Global.Microsoft.VisualBasic.ChrW(40), Global.Microsoft.VisualBasic.ChrW(41), Global.Microsoft.VisualBasic.ChrW(123), Global.Microsoft.VisualBasic.ChrW(125), Global.Microsoft.VisualBasic.ChrW(91), Global.Microsoft.VisualBasic.ChrW(93), Global.Microsoft.VisualBasic.ChrW(34), Global.Microsoft.VisualBasic.ChrW(34), Global.Microsoft.VisualBasic.ChrW(39), Global.Microsoft.VisualBasic.ChrW(39)}
        Me.txtCode.AutoIndentCharsPatterns = ""
        Me.txtCode.AutoScrollMinSize = New System.Drawing.Size(221, 18)
        Me.txtCode.BackBrush = Nothing
        Me.txtCode.CharHeight = 18
        Me.txtCode.CharWidth = 10
        Me.txtCode.CommentPrefix = Nothing
        Me.txtCode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCode.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.txtCode.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtCode.Font = New System.Drawing.Font("Courier New", 12.0!)
        Me.txtCode.IsReplaceMode = False
        Me.txtCode.Language = FastColoredTextBoxNS.Language.HTML
        Me.txtCode.LeftBracket = Global.Microsoft.VisualBasic.ChrW(60)
        Me.txtCode.LeftBracket2 = Global.Microsoft.VisualBasic.ChrW(40)
        Me.txtCode.Location = New System.Drawing.Point(3, 3)
        Me.txtCode.Name = "txtCode"
        Me.txtCode.Paddings = New System.Windows.Forms.Padding(0)
        Me.txtCode.RightBracket = Global.Microsoft.VisualBasic.ChrW(62)
        Me.txtCode.RightBracket2 = Global.Microsoft.VisualBasic.ChrW(41)
        Me.txtCode.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCode.ServiceColors = CType(resources.GetObject("txtCode.ServiceColors"), FastColoredTextBoxNS.ServiceColors)
        Me.txtCode.Size = New System.Drawing.Size(476, 139)
        Me.txtCode.TabIndex = 0
        Me.txtCode.Text = "FastColoredTextBox1"
        Me.txtCode.Zoom = 100
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.gridAttributes)
        Me.TabPage4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.TabPage4.ImageIndex = 1
        Me.TabPage4.Location = New System.Drawing.Point(4, 23)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(602, 316)
        Me.TabPage4.TabIndex = 1
        Me.TabPage4.Text = "Attributes  (F2)"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'gridAttributes
        '
        Me.gridAttributes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridAttributes.ColumnHeadersVisible = False
        Me.gridAttributes.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAtt, Me.colText})
        Me.gridAttributes.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gridAttributes.EnableHeadersVisualStyles = False
        Me.gridAttributes.Location = New System.Drawing.Point(3, 3)
        Me.gridAttributes.MultiSelect = False
        Me.gridAttributes.Name = "gridAttributes"
        Me.gridAttributes.RowHeadersVisible = False
        Me.gridAttributes.Size = New System.Drawing.Size(596, 310)
        Me.gridAttributes.TabIndex = 3
        '
        'colAtt
        '
        Me.colAtt.HeaderText = "Column1"
        Me.colAtt.Name = "colAtt"
        Me.colAtt.Width = 50
        '
        'colText
        '
        Me.colText.HeaderText = "colText"
        Me.colText.Name = "colText"
        Me.colText.Width = 150
        '
        '_tableResult
        '
        Me._tableResult.ColumnCount = 1
        Me._tableResult.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me._tableResult.Controls.Add(Me.TableLayoutPanel1, 0, 0)
        Me._tableResult.Dock = System.Windows.Forms.DockStyle.Fill
        Me._tableResult.Location = New System.Drawing.Point(0, 0)
        Me._tableResult.Name = "_tableResult"
        Me._tableResult.RowCount = 2
        Me._tableResult.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me._tableResult.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me._tableResult.Size = New System.Drawing.Size(133, 343)
        Me._tableResult.TabIndex = 0
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.ComboBox1, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(127, 29)
        Me.TableLayoutPanel1.TabIndex = 3
        '
        'ComboBox1
        '
        Me.ComboBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Web style", "Word style", "Android style"})
        Me.ComboBox1.Location = New System.Drawing.Point(53, 3)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(335, 24)
        Me.ComboBox1.TabIndex = 5
        Me.ComboBox1.Text = "Android style"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Padding = New System.Windows.Forms.Padding(0, 5, 0, 0)
        Me.Label7.Size = New System.Drawing.Size(38, 21)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Style"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.ViewToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(908, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btOpen, Me.btSave, Me.ToolStripSeparator2, Me.ToolStripButton2, Me.ToolStripSeparator1, Me.ToolStripButton3, Me.ToolStripButton4, Me.ToolStripButton5, Me.ToolStripButton6, Me.ToolStripButton7, Me.ToolStripButton8, Me.ToolStripButton9, Me.ToolStripButton10, Me.ToolStripButton11, Me.ToolStripButton12, Me.ToolStripDropDownButton1, Me.ToolStripButton1, Me.ToolStripButton13})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(398, 25)
        Me.ToolStrip1.TabIndex = 0
        '
        'btOpen
        '
        Me.btOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btOpen.Image = Global.Dictionary_Maker.My.Resources.Resources.folder
        Me.btOpen.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btOpen.Name = "btOpen"
        Me.btOpen.Size = New System.Drawing.Size(23, 22)
        '
        'btSave
        '
        Me.btSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btSave.Image = Global.Dictionary_Maker.My.Resources.Resources.save
        Me.btSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btSave.Name = "btSave"
        Me.btSave.Size = New System.Drawing.Size(23, 22)
        Me.btSave.Text = "ToolStripButton14"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton2.Text = "ToolStripButton2"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton3.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_content_cut_black_18dp
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton3.Text = "ToolStripButton3"
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), System.Drawing.Image)
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton4.Text = "ToolStripButton4"
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton5.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_format_align_left_black_18dp
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton5.Text = "ToolStripButton5"
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton6.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_format_align_right_black_18dp
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton6.Text = "ToolStripButton6"
        '
        'ToolStripButton7
        '
        Me.ToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton7.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_format_align_center_black_18dp
        Me.ToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton7.Name = "ToolStripButton7"
        Me.ToolStripButton7.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton7.Text = "ToolStripButton7"
        '
        'ToolStripButton8
        '
        Me.ToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton8.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_format_bold_black_18dp
        Me.ToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton8.Name = "ToolStripButton8"
        Me.ToolStripButton8.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton8.Text = "ToolStripButton8"
        '
        'ToolStripButton9
        '
        Me.ToolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton9.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_format_italic_black_18dp
        Me.ToolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton9.Name = "ToolStripButton9"
        Me.ToolStripButton9.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton9.Text = "ToolStripButton9"
        '
        'ToolStripButton10
        '
        Me.ToolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton10.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_format_underlined_black_18dp
        Me.ToolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton10.Name = "ToolStripButton10"
        Me.ToolStripButton10.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton10.Text = "ToolStripButton10"
        '
        'ToolStripButton11
        '
        Me.ToolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton11.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_border_all_black_18dp
        Me.ToolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton11.Name = "ToolStripButton11"
        Me.ToolStripButton11.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton11.Text = "ToolStripButton11"
        '
        'ToolStripButton12
        '
        Me.ToolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton12.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_format_color_fill_black_18dp
        Me.ToolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton12.Name = "ToolStripButton12"
        Me.ToolStripButton12.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton12.Text = "ToolStripButton12"
        '
        'ToolStripDropDownButton1
        '
        Me.ToolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripDropDownButton1.Image = CType(resources.GetObject("ToolStripDropDownButton1.Image"), System.Drawing.Image)
        Me.ToolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton1.Name = "ToolStripDropDownButton1"
        Me.ToolStripDropDownButton1.Size = New System.Drawing.Size(29, 22)
        Me.ToolStripDropDownButton1.Text = "ToolStripDropDownButton1"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_undo_black_18dp
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton1.Text = "ToolStripButton1"
        '
        'ToolStripButton13
        '
        Me.ToolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton13.Image = Global.Dictionary_Maker.My.Resources.Resources.ic_redo_black_18dp
        Me.ToolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton13.Name = "ToolStripButton13"
        Me.ToolStripButton13.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton13.Text = "ToolStripButton13"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(908, 414)
        Me.Controls.Add(Me.ToolStripContainer1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Dictionary Maker"
        Me.ToolStripContainer1.BottomToolStripPanel.ResumeLayout(False)
        Me.ToolStripContainer1.BottomToolStripPanel.PerformLayout()
        Me.ToolStripContainer1.ContentPanel.ResumeLayout(False)
        Me.ToolStripContainer1.TopToolStripPanel.ResumeLayout(False)
        Me.ToolStripContainer1.TopToolStripPanel.PerformLayout()
        Me.ToolStripContainer1.ResumeLayout(False)
        Me.ToolStripContainer1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.tabList.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me._tableEntry.ResumeLayout(False)
        Me._tableEntry.PerformLayout()
        Me._tableEntryButton.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.tabEdit.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.contextDerive.ResumeLayout(False)
        Me.contextEtymo.ResumeLayout(False)
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage8.ResumeLayout(False)
        CType(Me.txtCode, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        CType(Me.gridAttributes, System.ComponentModel.ISupportInitialize).EndInit()
        Me._tableResult.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ToolStripContainer1 As ToolStripContainer
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btOpen As ToolStripButton
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents tabList As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents listSearch As ListBox
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents _tableEntry As TableLayoutPanel
    Friend WithEvents tabEdit As TabControl
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents gridAttributes As DataGridView
    Friend WithEvents colAtt As DataGridViewCheckBoxColumn
    Friend WithEvents colText As DataGridViewTextBoxColumn
    Friend WithEvents ToolStripButton2 As ToolStripButton
    Friend WithEvents img16 As ImageList
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripButton3 As ToolStripButton
    Friend WithEvents ToolStripButton4 As ToolStripButton
    Friend WithEvents ToolStripButton5 As ToolStripButton
    Friend WithEvents ToolStripButton6 As ToolStripButton
    Friend WithEvents ToolStripButton7 As ToolStripButton
    Friend WithEvents ToolStripButton8 As ToolStripButton
    Friend WithEvents ToolStripButton9 As ToolStripButton
    Friend WithEvents ToolStripButton10 As ToolStripButton
    Friend WithEvents ToolStripButton11 As ToolStripButton
    Friend WithEvents ToolStripButton12 As ToolStripButton
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripDropDownButton1 As ToolStripDropDownButton
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents ToolStripButton13 As ToolStripButton
    Friend WithEvents _tableEntryButton As TableLayoutPanel
    Private WithEvents listWord As ComponentFactory.Krypton.Toolkit.KryptonListBox
    Friend WithEvents ToolStrip2 As ToolStrip
    Friend WithEvents btBold As ToolStripButton
    Friend WithEvents Label8 As Label
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents _tableResult As TableLayoutPanel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents btItalic As ToolStripButton
    Friend WithEvents btUnderline As ToolStripButton
    Friend WithEvents btTable As ToolStripButton
    Friend WithEvents btColors As ToolStripButton
    Friend WithEvents txtCode As FastColoredTextBoxNS.FastColoredTextBox
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents btSave As ToolStripButton
    Private WithEvents btNewEntry As ComponentFactory.Krypton.Toolkit.KryptonButton
    Private WithEvents btDeleteEntry As ComponentFactory.Krypton.Toolkit.KryptonButton
    Private WithEvents txtSearchEntry As ComponentFactory.Krypton.Toolkit.KryptonTextBox
    Friend WithEvents ToolStripButton14 As ToolStripButton
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents ToolStripButton15 As ToolStripButton
    Friend WithEvents ToolStripButton16 As ToolStripButton
    Friend WithEvents ToolStripButton17 As ToolStripButton
    Friend WithEvents ToolStripButton18 As ToolStripButton
    Friend WithEvents ToolStripButton19 As ToolStripButton
    Friend WithEvents ToolStripButton20 As ToolStripButton
    Friend WithEvents ToolStripButton21 As ToolStripButton
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents ToolStripButton22 As ToolStripButton
    Friend WithEvents ToolStripButton23 As ToolStripButton
    Friend WithEvents ToolStripButton24 As ToolStripButton
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents ToolStripButton25 As ToolStripButton
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents ToolStripButton26 As ToolStripButton
    Private WithEvents txtWord As ComponentFactory.Krypton.Toolkit.KryptonTextBox
    Private WithEvents txtPronounciation As ComponentFactory.Krypton.Toolkit.KryptonTextBox
    Private WithEvents txtDerive As ComponentFactory.Krypton.Toolkit.KryptonTextBox
    Private WithEvents txtEtymology As ComponentFactory.Krypton.Toolkit.KryptonTextBox
    Friend WithEvents ButtonSpecAny1 As ComponentFactory.Krypton.Toolkit.ButtonSpecAny
    Friend WithEvents contextDerive As ContextMenuStrip
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents ButtonSpecAny2 As ComponentFactory.Krypton.Toolkit.ButtonSpecAny
    Friend WithEvents contextEtymo As ContextMenuStrip
    Friend WithEvents ToolStripMenuItem5 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As ToolStripMenuItem
End Class
